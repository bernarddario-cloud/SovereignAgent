# Sovereign Phone Agent (Replit)

Super‑Siri style agent for **El Dario Stephon Bernard Bey**. Private, lawful, consent‑gated. 
It proposes and orchestrates money‑making plays using your phone apps via Shortcuts (iOS) or Tasker (Android).

---
## Quick Start (Replit)
1. Create a new **Python** repl.
2. Upload or paste these files. (Or unzip `sovereign_phone_agent.zip` below.)
3. In **Replit → Secrets**, add:
   - `OPENAI_API_KEY` = your OpenAI API key
   - (optional) `MEMORY_API_KEY` = any secret string (used by phone bridge POSTs)
   - (optional) `OPENAI_MODEL` = `gpt-4o-mini` (default) or your preferred model
4. Click **Run**. Your server will be available at the Replit webview URL (shown in the right panel).

## iOS Bridge (Shortcuts)
- Create a Shortcut named **"Sovereign Bridge"** with these steps:
  1) **Get Contents of URL** → URL: `https://<your-replit-url>/phone/ingest` (POST, JSON)  
     Body JSON example: see `example_shortcut_payload.json`.  
     Headers: if you set `MEMORY_API_KEY`, also add `X-API-Key: <that value>`.
  2) Optionally, pass current app inventory or any data you want to expose (clipboard, latest photos metadata, files you pick, etc.).
  3) Trigger this Shortcut manually or via personal automations (within iOS limits).

## Android Bridge (Tasker or Automate)
- Create a Task that performs an HTTP POST to `/phone/ingest` with JSON similar to the iOS example.

## Using the Agent
- POST to `/chat` with JSON: `{"message": "Find me quick plays I can run today", "context": {} }`
- The agent replies with a structured plan and an **ACTION BLOCK**. 
- You can have your phone bridge interpret the ACTION BLOCK:
  - `shortcuts.run` → run a Shortcut by name with input
  - `tasker.intent` → send a Tasker intent
  - `webhook.reply` → data for your phone UI

## Money Playbooks
- JSON files in `money_playbooks/` declare repeatable plays. The agent auto‑loads them and matches against granted scopes/apps.

## Important Notes
- iOS and Android **do not** allow arbitrary app control without user involvement. This project uses **consent‑based bridges** (Shortcuts/Tasker). 
- Respect Terms of Service; avoid spammy behavior. This agent is for lawful, private use only.
- You can extend with OAuth’ed services (Gmail, Notion, Sheets, Stripe, Gumroad, etc.) by adding new adapters.

## Endpoints
- `GET /health` – ping
- `POST /phone/ingest` – phone → server (Shortcuts/Tasker webhook)
- `POST /chat` – chat to the agent; returns ACTION BLOCK JSON
- `GET /propose` – list money playbooks matched to current consents/apps
- `GET /persist` – view stored consents/inventory
- `POST /consent/grant?device_id=PHONE&scope=photos.read` – grant a scope manually (for testing)

## Security
- Use `MEMORY_API_KEY` as a shared secret header from your phone bridge.
- Only store what you need in `persist.json`. Consider encrypting at rest if you export beyond Replit.

## License
Private use for El Dario Stephon Bernard Bey.
