import os, json, asyncio
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel
from typing import Any, Dict, List
from dotenv import load_dotenv
import httpx

# OpenAI SDK (>=1.0)
try:
    from openai import OpenAI
except Exception:
    OpenAI = None

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
MEMORY_API_KEY = os.getenv("MEMORY_API_KEY", "")  # optional shared-secret for phone bridge
PORT = int(os.getenv("PORT", "8000"))

app = FastAPI(title="Sovereign Phone Agent")

PERSIST_PATH = "persist.json"
PLAYBOOK_DIR = "money_playbooks"

def load_persist() -> Dict[str, Any]:
    if os.path.exists(PERSIST_PATH):
        with open(PERSIST_PATH, "r") as f:
            return json.load(f)
    return {"consents": {}, "app_inventory": [], "task_log": []}

def save_persist(data: Dict[str, Any]):
    with open(PERSIST_PATH, "w") as f:
        json.dump(data, f, indent=2)

def load_playbooks() -> List[Dict[str, Any]]:
    plays = []
    if os.path.isdir(PLAYBOOK_DIR):
        for name in os.listdir(PLAYBOOK_DIR):
            if name.endswith(".json"):
                with open(os.path.join(PLAYBOOK_DIR, name)) as f:
                    plays.append(json.load(f))
    return plays

SYSTEM_PROMPT_PATH = "system_prompt.txt"
if os.path.exists(SYSTEM_PROMPT_PATH):
    with open(SYSTEM_PROMPT_PATH, "r") as f:
        SYSTEM_PROMPT = f.read()
else:
    SYSTEM_PROMPT = "You are a helpful agent."

class ChatIn(BaseModel):
    message: str
    context: Dict[str, Any] = {}

class IngestPayload(BaseModel):
    # Phone bridge posts here (Shortcuts/Tasker)
    # Include optional shared secret in header: X-API-Key
    device_id: str
    app_inventory: List[str] = []
    granted_scopes: List[str] = []
    data: Dict[str, Any] = {}

def build_messages(user_message: str, context: Dict[str, Any]) -> List[Dict[str, str]]:
    persist = load_persist()
    playbooks = load_playbooks()
    sys_context = {
        "persist": persist,
        "available_playbooks": [p.get("name") for p in playbooks],
        "context": context,
    }
    return [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "system", "content": json.dumps(sys_context)},
        {"role": "user", "content": user_message}
    ]

async def llm(messages: List[Dict[str, str]]) -> str:
    if not OPENAI_API_KEY or OpenAI is None:
        return json.dumps({"actions": [], "error": "OPENAI_API_KEY missing or openai SDK not available"})
    client = OpenAI(api_key=OPENAI_API_KEY)
    resp = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        temperature=0.2
    )
    return resp.choices[0].message.content

@app.get("/health")
async def health():
    return {"ok": True}

@app.post("/chat")
async def chat(inp: ChatIn):
    messages = build_messages(inp.message, inp.context)
    content = await llm(messages)
    # Try to parse ACTION BLOCK from tail; if not JSON, wrap as a webhook reply
    try:
        parsed = json.loads(content)
        return JSONResponse(parsed)
    except Exception:
        return JSONResponse({"actions": [{
            "tool": "webhook.reply",
            "args": {"payload": {"text": content}}
        }]})

@app.post("/phone/ingest")
async def ingest(payload: IngestPayload, request: Request):
    # Optional shared-secret check
    if MEMORY_API_KEY:
        apikey = request.headers.get("X-API-Key", "")
        if apikey != MEMORY_API_KEY:
            return JSONResponse({"error": "forbidden"}, status_code=403)
    persist = load_persist()
    # Update local state
    persist["app_inventory"] = list(sorted(set(payload.app_inventory)))
    persist["consents"][payload.device_id] = payload.granted_scopes
    if payload.data:
        persist["last_data"] = payload.data
    save_persist(persist)
    return {"ok": True, "persist": persist}

@app.get("/persist")
async def get_persist():
    return load_persist()

@app.post("/consent/grant")
async def grant_consent(device_id: str, scope: str):
    persist = load_persist()
    scopes = set(persist["consents"].get(device_id, []))
    scopes.add(scope)
    persist["consents"][device_id] = sorted(scopes)
    save_persist(persist)
    return {"ok": True, "consents": persist["consents"][device_id]}

@app.get("/playbooks")
async def list_playbooks():
    return load_playbooks()

# Convenience: propose money plays based on app inventory + scopes
@app.get("/propose")
async def propose():
    persist = load_persist()
    plays = load_playbooks()
    inventory = set(persist.get("app_inventory", []))
    device_scopes = set()
    if persist.get("consents"):
        # use first device's consents
        device_scopes = set(list(persist["consents"].values())[0])

    matched = []
    for p in plays:
        needed = set(p.get("needed_scopes", []))
        if needed.issubset(device_scopes):
            matched.append(p)
        else:
            # If only web scopes are needed, still propose but mark missing
            missing = list(needed - device_scopes)
            p2 = dict(p)
            p2["missing_scopes"] = missing
            matched.append(p2)
    return {"inventory": list(inventory), "plays": matched}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=PORT)
